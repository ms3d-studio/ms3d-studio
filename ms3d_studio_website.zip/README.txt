MS3D Studio - Sitio estático listo para abrir
============================================

Archivos incluidos:
- index.html       -> Página principal (HTML + CSS + JS embebido)
- assets/logo.png  -> Logo proporcionado y usado en la web

Instrucciones rápidas:
1) Descarga y descomprime este ZIP.
2) Reemplaza el placeholder de Formspree en el formulario:
   action="https://formspree.io/f/YOUR_FORM_ID"
   -> Crea un formulario en https://formspree.io/ y pega tu ID en esa URL.
3) Abre index.html en el navegador (doble clic) para ver la web localmente.
4) Para publicar en GitHub Pages o en cualquier hosting, sube todo el contenido de la carpeta.

Si quieres, puedo:
- Cambiar el logo a otro formato (SVG).
- Generar una versión optimizada para producción.
- Subirlo directamente a GitHub Pages si me das permiso para crear un repositorio (te doy los pasos).

